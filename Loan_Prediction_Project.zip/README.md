
# Loan Prediction Project

This is a simple machine learning project using basic tools to predict loan approval.

## Contents
- Simple CSV dataset
- Random Forest model
- Easy-to-understand Python code

## How to Run
```
cd src
python loan_prediction.py
```
